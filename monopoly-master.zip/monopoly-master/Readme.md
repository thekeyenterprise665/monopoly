# monopoly

A JavaScript/HTML/CSS Monopoly implementation with full game play. Supports two-eight players.

Play online at [http://www.intrepidcoder.com/projects/monopoly/](http://www.intrepidcoder.com/projects/monopoly/).

Includes an experimental capability to play against an AI. A test AI for demonstration purposes is included.
